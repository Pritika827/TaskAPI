package com.task.employee.model;


public class EmployeeVo {

	private int empId;
	private String empName;
	private String empEmail;
	public EmployeeVo() {
		super();
	}
	public EmployeeVo(int empId, String empName, String empEmail) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	@Override
	public String toString() {
		return "EmployeeVo [empId=" + empId + ", empName=" + empName + ", empEmail=" + empEmail + "]";
	}
	

	
}
